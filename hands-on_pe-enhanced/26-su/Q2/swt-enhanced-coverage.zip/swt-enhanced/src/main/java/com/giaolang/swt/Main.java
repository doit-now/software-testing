package com.giaolang.swt;


public class Main {


    static void main() {
        System.out.println(Math.sqrt(-5));
    }


}
