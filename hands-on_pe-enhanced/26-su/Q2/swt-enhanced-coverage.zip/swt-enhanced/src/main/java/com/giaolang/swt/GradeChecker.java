package com.giaolang.swt;

public class GradeChecker {

    // Hàm xét trạng thái đậu rớt để in lên bảng điểm
    // score: điểm số theo thang điểm 10
    public static String checkResult(int score) {

        String result = "";
        if (score >= 5) {
            result = "Passed";
        } else {
            result = "Failed";
        }
        return result;
    }
}
