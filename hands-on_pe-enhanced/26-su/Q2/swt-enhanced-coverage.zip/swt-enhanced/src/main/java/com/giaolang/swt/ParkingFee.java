package com.giaolang.swt;

public class ParkingFee {

    // Hàm tính phí giữ xe theo giờ, có giảm giá cho khách hàng quen
    // phí giữ xe 5000 / giờ, giảm 2000 nếu là khách hàng quen
    // hours: số giờ gửi xe
    // hasMemberCard: có là khách quen hay không?
    public static int calculateFee(int hours, boolean hasMemberCard) {

        int fee = 0;
        if (hours <= 0) {
            fee = 0;
        } else {
            fee = hours * 5000;     // tiền gửi chưa giảm
            if (hasMemberCard) {
                fee = fee - 2000;   // giảm 2000 cho khách quen
            }
        }
        return fee;
    }
}
