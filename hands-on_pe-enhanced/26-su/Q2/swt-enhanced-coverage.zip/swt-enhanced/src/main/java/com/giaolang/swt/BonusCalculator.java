package com.giaolang.swt;

public class BonusCalculator {

    // Hàm tính điểm cuối kỳ môn SWE201c (ví dụ)
    // sinh viên được thưởng điểm nếu hoàn tất chứng chỉ môn sớm
    // score: điểm cuối kỳ
    // submittedEarly: có nộp chứng chỉ sớm ko?
    public static int calculateFinalScore(int score, boolean submittedEarly) {

        int finalScore = score;
        if (submittedEarly) {
            finalScore = finalScore + 10;   // thưởng 10 điểm nếu nộp chứng chỉ sớm
        }
        return finalScore;
    }
}
