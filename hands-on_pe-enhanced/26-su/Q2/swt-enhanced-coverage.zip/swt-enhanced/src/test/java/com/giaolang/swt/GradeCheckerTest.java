package com.giaolang.swt;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GradeCheckerTest {

    @Test
    void checkResult_scoreGreaterOrEqual5_returnsPassed() {
        // Nhánh true của: if (score >= 5)
        // Cover statement: result = "Passed";
        String result = GradeChecker.checkResult(5);
        assertEquals("Passed", result);
    }

    @Test
    void checkResult_scoreLessThan5_returnsFailed() {
        // Nhánh false của: if (score >= 5)
        // Cover statement: result = "Failed";
        String result = GradeChecker.checkResult(4);
        assertEquals("Failed", result);
    }
}