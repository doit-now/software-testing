package com.giaolang.swt;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ParkingFeeTest {

    @Test
    void calculateFee_hoursZeroOrNegative_returnsZeroFee() {
        // Nhánh true của: if (hours <= 0)
        // Nhánh if (hasMemberCard) bên trong KHÔNG được chạy tới (nằm trong else)
        int fee = ParkingFee.calculateFee(0, false);
        assertEquals(0, fee);
    }

    @Test
    void calculateFee_hoursPositive_notMemberCard_returnsFullFee() {
        // Nhánh false của: if (hours <= 0)  → vào else
        // Nhánh false của: if (hasMemberCard)
        int fee = ParkingFee.calculateFee(3, false);
        assertEquals(15000, fee); // 3 * 5000 = 15000, không giảm
    }

    @Test
    void calculateFee_hoursPositive_hasMemberCard_returnsDiscountedFee() {
        // Nhánh false của: if (hours <= 0)  → vào else
        // Nhánh true của: if (hasMemberCard)
        // Cover statement: fee = fee - 2000;
        int fee = ParkingFee.calculateFee(3, true);
        assertEquals(13000, fee); // 3 * 5000 - 2000 = 13000
    }
}