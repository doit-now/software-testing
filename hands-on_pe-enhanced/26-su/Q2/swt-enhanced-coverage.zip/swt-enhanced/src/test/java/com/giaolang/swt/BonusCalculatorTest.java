package com.giaolang.swt;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BonusCalculatorTest {

    //QUY ƯỚC ĐẶT TÊN HÀM KIỂM THỬ (CÓ NHIỀU CÁCH)
    //Ở ĐÂY: methodName_condition_expectedResult

    @Test
    void calculateFinalScore_submittedEarly_addsBonus() {
        // Nhánh true: if (submittedEarly)
        int result = BonusCalculator.calculateFinalScore(80, true);
        assertEquals(90, result);
    }

    @Test
    //@Disabled
    void calculateFinalScore_notSubmittedEarly_noBonus() {
        // Nhánh false: if (submittedEarly)
        int result = BonusCalculator.calculateFinalScore(80, false);
        assertEquals(80, result);
    }
}